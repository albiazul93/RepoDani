﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace back_MSI_SuperMami.DTOs
{
    public class DTOOrdenDeCompra
    {
        public string Proveedor { get; set; }
        public string FormaDePago { get; set; }
        public string FormaDeEnvio { get; set; }
        public string Estado { get; set; }


    }
}
