﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace back_MSI_SuperMami.Comandos
{
    public class ComandoUsuarioLogin
    {
        public string email { get; set; }
        public string password { get; set; }
    }
}
